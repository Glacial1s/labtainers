export WATERMARK_HOME=/home/student/watermark
cd "$WATERMARK_HOME" 2>/dev/null || true
echo "Lab 1 - DCT Watermark in MPEG I-frame"
echo "Run: bash lab1/run_lab1.sh"
alias runlab='bash lab1/run_lab1.sh'
