Lab 1 - DCT Watermark in MPEG I-frame

Sequential workflow inside the Labtainer container:
    cd /home/student/watermark
    bash lab1/01_extract_iframe.sh
    bash lab1/02_embed_dct_watermark.sh
    bash lab1/03_extract_watermark_bits.sh
    bash lab1/04_evaluate_quality.sh
    bash lab1/05_finalize_lab1.sh

Main evidence files:
    lab1/iframe_original.png
    lab1/iframe_watermarked.png
    lab1/result.txt

The old single wrapper bash lab1/run_lab1.sh is kept only for compatibility. The recommended student workflow is to run the numbered steps above.
