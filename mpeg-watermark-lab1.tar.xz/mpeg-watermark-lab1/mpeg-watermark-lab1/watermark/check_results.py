#!/usr/bin/env python3
from pathlib import Path
import re
BASE = Path('/home/student/watermark')
p = BASE/'lab1/result.txt'
text = p.read_text(encoding='utf-8') if p.exists() else ''
def f(pattern, default):
    m = re.search(pattern, text)
    return float(m.group(1)) if m else default
psnr = f(r'psnr=([0-9.]+)', 0.0)
ssim = f(r'ssim=([0-9.]+)', 0.0)
ber = f(r'ber=([0-9.]+)', 100.0)
print(f'LAB1_DONE={int(p.exists())}')
print(f'LAB1_QUALITY_OK={int(psnr > 40 and ssim > 0.98)}')
print(f'LAB1_BER_OK={int(ber == 0.0)}')
