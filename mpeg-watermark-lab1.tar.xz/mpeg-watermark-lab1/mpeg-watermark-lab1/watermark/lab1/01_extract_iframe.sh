#!/bin/bash
set -euo pipefail
BASE="/home/student/watermark"
LAB1="$BASE/lab1"
MEDIA="$BASE/media"
mkdir -p "$LAB1"
rm -f "$LAB1/result.txt"
echo "[1/5] Extracting first MPEG I-frame from sample.mp4..."
ffmpeg -i "$MEDIA/sample.mp4" -vf "select=eq(pict_type\,I)" -vsync vfr -vframes 1 \
       "$LAB1/iframe_original.png" -y -loglevel quiet
echo "[+] Created: $LAB1/iframe_original.png"
