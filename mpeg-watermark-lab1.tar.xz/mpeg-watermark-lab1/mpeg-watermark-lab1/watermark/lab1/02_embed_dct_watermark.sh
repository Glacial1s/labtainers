#!/bin/bash
set -euo pipefail
LAB1="/home/student/watermark/lab1"
echo "[2/5] Embedding watermark bits into DCT mid-frequency coefficients..."
python3 "$LAB1/embed_dct.py" "$LAB1/iframe_original.png" "$LAB1/iframe_watermarked.png" 0.05
echo "[+] Created: $LAB1/iframe_watermarked.png"
