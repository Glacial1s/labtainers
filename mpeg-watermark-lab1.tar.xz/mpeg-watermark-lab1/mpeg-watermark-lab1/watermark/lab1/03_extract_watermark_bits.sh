#!/bin/bash
set -euo pipefail
LAB1="/home/student/watermark/lab1"
echo "[3/5] Extracting watermark bits and measuring BER..."
python3 "$LAB1/extract_dct.py" "$LAB1/iframe_original.png" "$LAB1/iframe_watermarked.png" "$LAB1/result.txt"
echo "[+] Updated: $LAB1/result.txt"
