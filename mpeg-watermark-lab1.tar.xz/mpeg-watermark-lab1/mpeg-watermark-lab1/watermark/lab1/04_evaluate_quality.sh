#!/bin/bash
set -euo pipefail
LAB1="/home/student/watermark/lab1"
echo "[4/5] Measuring PSNR and SSIM between original and watermarked frames..."
python3 "$LAB1/evaluate.py" "$LAB1/iframe_original.png" "$LAB1/iframe_watermarked.png" "$LAB1/result.txt"
echo "[+] Updated: $LAB1/result.txt"
