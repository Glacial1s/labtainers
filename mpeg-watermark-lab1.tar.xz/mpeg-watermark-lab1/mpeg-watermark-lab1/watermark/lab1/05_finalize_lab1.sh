#!/bin/bash
set -euo pipefail
LAB1="/home/student/watermark/lab1"
echo "[5/5] Finalizing Lab 1 evidence marker..."
echo "lab1_done=1" >> "$LAB1/result.txt"
cat "$LAB1/result.txt"
echo "[+] Lab 1 sequential workflow complete."
