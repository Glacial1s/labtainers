#!/usr/bin/env python3
"""Lab 1: Embed watermark bits into DCT coefficients of an I-frame.
The implementation is intentionally small but robust enough to survive PNG round-trip.
"""
import cv2
import numpy as np
import sys

MID_FREQ = [(2,1),(1,2),(0,3),(1,3),(2,2),(3,1),(4,0),(3,2),(2,3),(1,4)]
DEFAULT_BITS = [1,0,1,1,0,0,1,1,0,1,0,0,1,0,1,0]

def embed_dct_watermark(img_path, watermark_bits, alpha=0.05, out_path=None):
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {img_path}")
    frame = img.astype(np.float32)
    h, w = frame.shape
    wm_idx = 0
    min_delta = max(2.0, 420.0 * float(alpha))  # 21.0 when alpha=0.05

    for row in range(0, h - 7, 8):
        for col in range(0, w - 7, 8):
            if wm_idx >= len(watermark_bits):
                break
            block = frame[row:row+8, col:col+8]
            D = cv2.dct(block)
            u, v = MID_FREQ[wm_idx % len(MID_FREQ)]
            coeff = D[u, v]
            delta = max(min_delta, abs(coeff) * float(alpha))
            D[u, v] = coeff + delta if watermark_bits[wm_idx] else coeff - delta
            frame[row:row+8, col:col+8] = cv2.idct(D)
            wm_idx += 1
        if wm_idx >= len(watermark_bits):
            break

    result = np.clip(frame, 0, 255).astype(np.uint8)
    if out_path:
        cv2.imwrite(out_path, result)
        print(f"[+] Saved watermarked image: {out_path}")
    return result

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 embed_dct.py <input.png> <output.png> [alpha]")
        sys.exit(1)
    inp = sys.argv[1]
    out = sys.argv[2]
    alpha = float(sys.argv[3]) if len(sys.argv) > 3 else 0.05
    embed_dct_watermark(inp, DEFAULT_BITS, alpha, out)
