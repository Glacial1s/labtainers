#!/usr/bin/env python3
"""Lab 1: Measure PSNR and SSIM between original and watermarked images."""
import cv2
import numpy as np
import sys
from pathlib import Path
from skimage.metrics import structural_similarity as ssim

def compute_psnr(orig, wm):
    mse = np.mean((orig.astype(float) - wm.astype(float)) ** 2)
    return float("inf") if mse == 0 else 10 * np.log10(255 ** 2 / mse)

def compute_ssim(orig, wm):
    return ssim(orig, wm, data_range=255)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 evaluate.py <original.png> <watermarked.png> [result.txt]")
        sys.exit(1)
    o = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
    w = cv2.imread(sys.argv[2], cv2.IMREAD_GRAYSCALE)
    if o is None or w is None:
        raise FileNotFoundError("Cannot read original or watermarked image")
    psnr = compute_psnr(o, w)
    s = compute_ssim(o, w)
    print(f"PSNR : {psnr:.2f} dB  (good threshold: > 40 dB)")
    print(f"SSIM : {s:.4f}  (good threshold: > 0.98)")
    result_path = Path(sys.argv[3]) if len(sys.argv) > 3 else Path("/home/student/watermark/lab1/result.txt")
    result_path.parent.mkdir(parents=True, exist_ok=True)
    old = result_path.read_text(encoding='utf-8') if result_path.exists() else ''
    result_path.write_text(old + f"psnr={psnr:.2f}\nssim={s:.4f}\n", encoding='utf-8')
    print(f"[+] Saved results to {result_path}")
