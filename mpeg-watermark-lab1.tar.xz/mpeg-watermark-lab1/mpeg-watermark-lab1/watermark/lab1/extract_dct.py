#!/usr/bin/env python3
"""Lab 1: Extract watermark bits from DCT coefficients by comparing original and marked frames."""
import cv2
import numpy as np
import sys
from pathlib import Path

MID_FREQ = [(2,1),(1,2),(0,3),(1,3),(2,2),(3,1),(4,0),(3,2),(2,3),(1,4)]
DEFAULT_BITS = [1,0,1,1,0,0,1,1,0,1,0,0,1,0,1,0]

def extract_dct_watermark(orig_path, wm_path, num_bits=16):
    orig_img = cv2.imread(orig_path, cv2.IMREAD_GRAYSCALE)
    wm_img = cv2.imread(wm_path, cv2.IMREAD_GRAYSCALE)
    if orig_img is None or wm_img is None:
        raise FileNotFoundError("Cannot read original or watermarked image")
    orig = orig_img.astype(np.float32)
    wm = wm_img.astype(np.float32)
    h, w = orig.shape
    bits, idx = [], 0
    for row in range(0, h - 7, 8):
        for col in range(0, w - 7, 8):
            if len(bits) >= num_bits:
                break
            Do = cv2.dct(orig[row:row+8, col:col+8])
            Dw = cv2.dct(wm[row:row+8, col:col+8])
            u, v = MID_FREQ[idx % len(MID_FREQ)]
            bits.append(1 if Dw[u, v] > Do[u, v] else 0)
            idx += 1
        if len(bits) >= num_bits:
            break
    return bits

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 extract_dct.py <original.png> <watermarked.png> [result.txt]")
        sys.exit(1)
    bits = extract_dct_watermark(sys.argv[1], sys.argv[2])
    expected = DEFAULT_BITS
    ber = sum(a != b for a, b in zip(expected, bits)) / len(expected) * 100
    print(f"Extracted bits : {bits}")
    print(f"Original bits  : {expected}")
    print(f"BER            : {ber:.1f}%")
    if len(sys.argv) > 3:
        result_path = Path(sys.argv[3])
        old = result_path.read_text(encoding='utf-8') if result_path.exists() else ''
        result_path.write_text(old + f"ber={ber:.1f}\n", encoding='utf-8')
