#!/bin/bash
set -euo pipefail
LAB1="/home/student/watermark/lab1"
bash "$LAB1/01_extract_iframe.sh"
bash "$LAB1/02_embed_dct_watermark.sh"
bash "$LAB1/03_extract_watermark_bits.sh"
bash "$LAB1/04_evaluate_quality.sh"
bash "$LAB1/05_finalize_lab1.sh"
