export WATERMARK_HOME=/home/student/watermark
cd "$WATERMARK_HOME" 2>/dev/null || true
echo "Lab 2 - Spread Spectrum MPEG Watermarking"
echo "Run: bash lab2/run_lab2.sh"
alias runlab='bash lab2/run_lab2.sh'
