Lab 2 - Spread Spectrum MPEG Watermarking

Sequential workflow inside the Labtainer container:
    cd /home/student/watermark
    bash lab2/01_extract_iframe.sh
    bash lab2/02_embed_spread_spectrum_bit.sh
    bash lab2/03_extract_spread_spectrum_bit.sh
    bash lab2/04_embed_watermark_video.sh
    bash lab2/05_measure_noise_quality.sh
    bash lab2/06_finalize_lab2.sh

Main evidence files:
    lab2/results/iframe_orig.png
    lab2/results/iframe_ss_wm.png
    lab2/results/watermarked.mp4
    lab2/results/ber_test.txt
    lab2/results/psnr_test.txt
    lab2/results/lab2_done.txt

The old single wrapper bash lab2/run_lab2.sh is kept only for compatibility. The recommended student workflow is to run the numbered steps above.
