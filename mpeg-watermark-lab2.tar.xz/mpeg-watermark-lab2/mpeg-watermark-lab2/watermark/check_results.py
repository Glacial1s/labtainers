#!/usr/bin/env python3
from pathlib import Path
import re
BASE = Path('/home/student/watermark/lab2/results')
ber_text = (BASE/'ber_test.txt').read_text(encoding='utf-8') if (BASE/'ber_test.txt').exists() else ''
psnr_text = (BASE/'psnr_test.txt').read_text(encoding='utf-8') if (BASE/'psnr_test.txt').exists() else ''
m1 = re.search(r'ber_gaussian=([0-9.]+)', ber_text)
m2 = re.search(r'avg_psnr=([0-9.]+)', psnr_text)
ber = float(m1.group(1)) if m1 else 100.0
psnr = float(m2.group(1)) if m2 else 0.0
print(f'LAB2_DONE={int((BASE/"lab2_done.txt").exists() and (BASE/"ber_test.txt").exists() and (BASE/"psnr_test.txt").exists())}')
print(f'LAB2_BER_OK={int(ber <= 25.0)}')
print(f'LAB2_QUALITY_OK={int(psnr > 35.0)}')
