#!/bin/bash
set -euo pipefail
BASE="/home/student/watermark"
LAB2="$BASE/lab2"
mkdir -p "$LAB2/results"
rm -f "$LAB2/results/ber_test.txt" "$LAB2/results/psnr_test.txt" "$LAB2/results/lab2_done.txt"
echo "[1/6] Extracting first MPEG I-frame from sample.mp4..."
ffmpeg -i "$BASE/media/sample.mp4" -vf "select=eq(pict_type\,I)" -vsync vfr -vframes 1 \
       "$LAB2/results/iframe_orig.png" -y -loglevel quiet
echo "[+] Created: $LAB2/results/iframe_orig.png"
