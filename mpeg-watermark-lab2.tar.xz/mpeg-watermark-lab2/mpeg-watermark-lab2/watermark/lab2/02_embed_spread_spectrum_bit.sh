#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
cd "$LAB2"
echo "[2/6] Embedding one spread-spectrum watermark bit into the I-frame..."
python3 embed_ss.py "$LAB2/results/iframe_orig.png" 1 secret2024 "$LAB2/results/iframe_ss_wm.png"
echo "[+] Created: $LAB2/results/iframe_ss_wm.png"
