#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
cd "$LAB2"
echo "[3/6] Extracting the embedded spread-spectrum bit..."
python3 extract_ss.py "$LAB2/results/iframe_orig.png" "$LAB2/results/iframe_ss_wm.png" secret2024
