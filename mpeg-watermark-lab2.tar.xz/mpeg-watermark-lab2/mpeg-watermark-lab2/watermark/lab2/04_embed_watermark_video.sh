#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
cd "$LAB2"
echo "[4/6] Embedding a bit sequence into the first video frames..."
python3 batch_embed.py
echo "[+] Created: $LAB2/results/watermarked.mp4"
