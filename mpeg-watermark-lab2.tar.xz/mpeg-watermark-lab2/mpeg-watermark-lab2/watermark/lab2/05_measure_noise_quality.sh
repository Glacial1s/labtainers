#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
cd "$LAB2"
echo "[5/6] Measuring BER under Gaussian noise and PSNR..."
python3 measure_noise_quality.py
