#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
echo "[6/6] Finalizing Lab 2 evidence marker..."
echo "lab2_done=1" > "$LAB2/results/lab2_done.txt"
cat "$LAB2/results/ber_test.txt"
cat "$LAB2/results/psnr_test.txt"
echo "[+] Lab 2 sequential workflow complete."
