#!/usr/bin/env python3
"""Lab 2: Embed a bit sequence across a short prefix of a video.

The original teaching code can process a full video. For Labtainer grading we
limit the demo video to a small number of frames so the lab remains responsive.
"""
import cv2
import os
from embed_ss import embed_ss


def embed_to_video(input_path, output_path, bits, secret_key, alpha=0.015, max_frames=8):
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        raise FileNotFoundError(input_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(output_path, fourcc, fps, (W, H), True)
    frame_idx = 0
    while frame_idx < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        bit = bits[frame_idx % len(bits)]
        wm_gray = embed_ss(gray, bit, secret_key, alpha, frame_idx)
        out.write(cv2.cvtColor(wm_gray, cv2.COLOR_GRAY2BGR))
        frame_idx += 1
    cap.release()
    out.release()
    print(f"[+] Watermarked video: {output_path}")
    print(f"    Total frames processed: {frame_idx}")


if __name__ == "__main__":
    bits = [1,0,1,1,0,0,1,1]
    key = b"secret2024"
    embed_to_video("/home/student/watermark/media/sample.mp4", "/home/student/watermark/lab2/results/watermarked.mp4", bits, key)
