#!/usr/bin/env python3
"""Lab 2: Embed one bit into a frame using DCT spread spectrum."""
import cv2
import numpy as np
import sys
from pn_sequence import generate_pn_sequence, create_midband_mask

def block_dct(frame):
    f = frame.astype(np.float32)
    dct = np.zeros_like(f, dtype=np.float32)
    h, w = f.shape
    for r in range(0, h - 7, 8):
        for c in range(0, w - 7, 8):
            dct[r:r+8, c:c+8] = cv2.dct(f[r:r+8, c:c+8])
    return dct

def block_idct(dct):
    result = np.zeros_like(dct, dtype=np.float32)
    h, w = dct.shape
    for r in range(0, h - 7, 8):
        for c in range(0, w - 7, 8):
            result[r:r+8, c:c+8] = cv2.idct(dct[r:r+8, c:c+8])
    return result

def embed_ss(frame_gray: np.ndarray, bit: int, secret_key: bytes, alpha=0.025, frame_idx=0) -> np.ndarray:
    if frame_gray is None:
        raise ValueError("frame_gray is None")
    f = frame_gray.astype(np.float32)
    h, w = f.shape
    dct = block_dct(f)
    pn = generate_pn_sequence(secret_key, h * w, frame_idx).reshape(h, w)
    mask = create_midband_mask(h, w)
    sign = 1.0 if int(bit) == 1 else -1.0
    strength = max(1.0, float(alpha) * 220.0)
    dct = dct + sign * strength * pn * mask
    result = block_idct(dct)
    return np.clip(result, 0, 255).astype(np.uint8)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 embed_ss.py <input.png> <bit> [key] [output.png]")
        sys.exit(1)
    img = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
    bit = int(sys.argv[2])
    key = sys.argv[3].encode() if len(sys.argv) > 3 else b"secret2024"
    out = sys.argv[4] if len(sys.argv) > 4 else "/tmp/ss_out.png"
    result = embed_ss(img, bit, key)
    cv2.imwrite(out, result)
    print(f"[+] Embedded bit={bit} -> {out}")
