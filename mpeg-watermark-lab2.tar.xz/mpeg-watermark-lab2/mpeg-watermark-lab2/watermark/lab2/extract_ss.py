#!/usr/bin/env python3
"""Lab 2: Extract a spread-spectrum bit by keyed correlation in the DCT domain."""
import cv2
import numpy as np
import sys
from pn_sequence import generate_pn_sequence, create_midband_mask

def block_dct(frame):
    f = frame.astype(np.float32)
    dct = np.zeros_like(f, dtype=np.float32)
    h, w = f.shape
    for r in range(0, h - 7, 8):
        for c in range(0, w - 7, 8):
            dct[r:r+8, c:c+8] = cv2.dct(f[r:r+8, c:c+8])
    return dct

def extract_ss(orig_gray, wm_gray, secret_key, frame_idx=0):
    if orig_gray is None or wm_gray is None:
        raise ValueError("orig_gray or wm_gray is None")
    if orig_gray.shape != wm_gray.shape:
        wm_gray = cv2.resize(wm_gray, (orig_gray.shape[1], orig_gray.shape[0]))
    diff = wm_gray.astype(np.float32) - orig_gray.astype(np.float32)
    h, w = diff.shape
    dct_diff = block_dct(diff)
    pn = generate_pn_sequence(secret_key, h * w, frame_idx).reshape(h, w)
    mask = create_midband_mask(h, w)
    corr = float(np.sum(dct_diff * pn * mask))
    return 1 if corr > 0 else 0

def correlation_score(orig_gray, wm_gray, secret_key, frame_idx=0):
    if orig_gray.shape != wm_gray.shape:
        wm_gray = cv2.resize(wm_gray, (orig_gray.shape[1], orig_gray.shape[0]))
    diff = wm_gray.astype(np.float32) - orig_gray.astype(np.float32)
    h, w = diff.shape
    dct_diff = block_dct(diff)
    pn = generate_pn_sequence(secret_key, h * w, frame_idx).reshape(h, w)
    mask = create_midband_mask(h, w)
    return float(np.sum(dct_diff * pn * mask))

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 extract_ss.py <original.png> <watermarked.png> [key]")
        sys.exit(1)
    orig = cv2.imread(sys.argv[1], cv2.IMREAD_GRAYSCALE)
    wm = cv2.imread(sys.argv[2], cv2.IMREAD_GRAYSCALE)
    key = sys.argv[3].encode() if len(sys.argv) > 3 else b"secret2024"
    bit = extract_ss(orig, wm, key)
    print(f"Extracted bit: {bit}")
