#!/usr/bin/env python3
"""Lab 2: Measure BER under Gaussian noise and average PSNR."""
import cv2
import numpy as np
from pathlib import Path
from extract_ss import extract_ss
from embed_ss import embed_ss
from skimage.metrics import peak_signal_noise_ratio

RESULTS = Path('/home/student/watermark/lab2/results')
orig = cv2.imread(str(RESULTS / 'iframe_orig.png'), cv2.IMREAD_GRAYSCALE)
if orig is None:
    raise FileNotFoundError('Missing results/iframe_orig.png. Run 01_extract_iframe.sh first.')
key = b'secret2024'
bits = [1, 0, 1, 1, 0, 0, 1, 1]
errors = 0
psnrs = []
for i, bit in enumerate(bits):
    wm = embed_ss(orig, bit, key, alpha=0.015, frame_idx=i)
    psnrs.append(peak_signal_noise_ratio(orig, wm, data_range=255))
    noise = np.random.default_rng(i).normal(0, 2.0, wm.shape).astype(np.float32)
    noisy = np.clip(wm.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    extracted = extract_ss(orig, noisy, key, i)
    errors += int(extracted != bit)
ber = errors / len(bits) * 100
avg_psnr = float(np.mean(psnrs))
print(f'BER with Gaussian noise sigma=2: {ber:.1f}%')
print(f'Average PSNR: {avg_psnr:.2f} dB')
RESULTS.mkdir(parents=True, exist_ok=True)
(RESULTS / 'ber_test.txt').write_text(f'ber_gaussian={ber:.1f}\n', encoding='utf-8')
(RESULTS / 'psnr_test.txt').write_text(f'avg_psnr={avg_psnr:.2f}\n', encoding='utf-8')
print(f'[+] Updated: {RESULTS / "ber_test.txt"}')
print(f'[+] Updated: {RESULTS / "psnr_test.txt"}')
