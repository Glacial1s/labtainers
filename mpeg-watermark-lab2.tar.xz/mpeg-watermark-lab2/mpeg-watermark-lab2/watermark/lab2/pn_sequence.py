#!/usr/bin/env python3
"""Lab 2: Generate keyed pseudo-random PN sequences for spread-spectrum watermarking."""
import hashlib
import hmac
import struct
import numpy as np

def generate_pn_sequence(secret_key: bytes, length: int, frame_index: int = 0) -> np.ndarray:
    seed_bytes = hmac.new(secret_key, struct.pack(">I", frame_index), hashlib.sha256).digest()
    seed_int = int.from_bytes(seed_bytes[:8], "big")
    rng = np.random.default_rng(seed_int)
    pn = rng.standard_normal(length).astype(np.float32)
    norm = np.linalg.norm(pn) / max(1, np.sqrt(length))
    return pn / (norm if norm else 1.0)

def create_midband_mask(h: int, w: int) -> np.ndarray:
    mask = np.zeros((h, w), dtype=np.float32)
    mid = [(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),
           (4,0),(3,1),(2,2),(1,3),(0,4),(0,5),(1,4),
           (2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3)]
    for r in range(0, h - 7, 8):
        for c in range(0, w - 7, 8):
            for (u, v) in mid:
                if r + u < h and c + v < w:
                    mask[r + u, c + v] = 1.0
    return mask
