#!/bin/bash
set -euo pipefail
LAB2="/home/student/watermark/lab2"
bash "$LAB2/01_extract_iframe.sh"
bash "$LAB2/02_embed_spread_spectrum_bit.sh"
bash "$LAB2/03_extract_spread_spectrum_bit.sh"
bash "$LAB2/04_embed_watermark_video.sh"
bash "$LAB2/05_measure_noise_quality.sh"
bash "$LAB2/06_finalize_lab2.sh"
