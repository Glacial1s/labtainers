export WATERMARK_HOME=/home/student/watermark
cd "$WATERMARK_HOME" 2>/dev/null || true
echo "Lab 3 - Robustness Against Re-encoding"
echo "Run: bash lab3/run_lab3.sh"
alias runlab='bash lab3/run_lab3.sh'
