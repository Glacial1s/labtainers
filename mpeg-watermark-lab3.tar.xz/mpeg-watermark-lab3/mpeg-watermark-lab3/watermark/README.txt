Lab 3 - Robustness Against Re-encoding

Sequential workflow inside the Labtainer container:
    cd /home/student/watermark
    bash lab3/01_prepare_inputs.sh
    bash lab3/02_test_ecc_codec.sh
    bash lab3/03_run_reencoding_robustness.sh
    bash lab3/04_plot_ber_curve.sh
    bash lab3/05_finalize_lab3.sh

Main evidence files:
    lab3/results/ber_results.txt
    lab3/results/ber_vs_bitrate.png
    lab3/results/reencoded_4000k.mp4
    lab3/results/reencoded_1000k.mp4
    lab3/results/reencoded_500k.mp4

Lab 3 uses Lab 2 spread-spectrum support code, but the dependency is now explicit in step 01_prepare_inputs.sh instead of automatically running the whole Lab 2 workflow.
