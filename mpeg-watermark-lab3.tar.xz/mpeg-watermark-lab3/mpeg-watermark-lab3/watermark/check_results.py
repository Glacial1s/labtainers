#!/usr/bin/env python3
from pathlib import Path
BASE = Path('/home/student/watermark/lab3/results')
ok = (BASE/'ber_results.txt').exists() and (BASE/'ber_vs_bitrate.png').exists()
print(f'LAB3_DONE={int(ok)}')
