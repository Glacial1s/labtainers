#!/bin/bash
set -euo pipefail
BASE="/home/student/watermark"
LAB2="$BASE/lab2"
mkdir -p "$LAB2/results"
cd "$LAB2"

echo "=== LAB 2: Spread Spectrum Watermarking ==="

echo "[1/5] Extracting I-frame..."
ffmpeg -i "$BASE/media/sample.mp4" -vf "select=eq(pict_type\,I)" -vsync vfr -vframes 1 \
       "$LAB2/results/iframe_orig.png" -y -loglevel quiet

echo "[2/5] Embedding spread-spectrum bit=1..."
python3 embed_ss.py "$LAB2/results/iframe_orig.png" 1 secret2024 "$LAB2/results/iframe_ss_wm.png"

echo "[3/5] Extracting test bit..."
python3 extract_ss.py "$LAB2/results/iframe_orig.png" "$LAB2/results/iframe_ss_wm.png" secret2024

echo "[4/5] Embedding into full video..."
python3 batch_embed.py

echo "[5/5] Measuring BER under Gaussian noise and PSNR..."
python3 - <<'PY'
import cv2, numpy as np
from pathlib import Path
from extract_ss import extract_ss
from embed_ss import embed_ss
from skimage.metrics import peak_signal_noise_ratio

orig = cv2.imread('results/iframe_orig.png', cv2.IMREAD_GRAYSCALE)
key = b'secret2024'
bits = [1,0,1,1,0,0,1,1]
errors = 0
psnrs = []
for i, bit in enumerate(bits):
    wm = embed_ss(orig, bit, key, alpha=0.015, frame_idx=i)
    psnrs.append(peak_signal_noise_ratio(orig, wm, data_range=255))
    noise = np.random.default_rng(i).normal(0, 2.0, wm.shape).astype(np.float32)
    noisy = np.clip(wm.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    extracted = extract_ss(orig, noisy, key, i)
    errors += int(extracted != bit)
ber = errors / len(bits) * 100
avg_psnr = float(np.mean(psnrs))
print(f'BER with Gaussian noise sigma=2: {ber:.1f}%')
print(f'Average PSNR: {avg_psnr:.2f} dB')
Path('results/ber_test.txt').write_text(f'ber_gaussian={ber:.1f}\n', encoding='utf-8')
Path('results/psnr_test.txt').write_text(f'avg_psnr={avg_psnr:.2f}\n', encoding='utf-8')
PY

echo "lab2_done=1" > "$LAB2/results/lab2_done.txt"
echo "Lab 2 complete: $LAB2/results/"
