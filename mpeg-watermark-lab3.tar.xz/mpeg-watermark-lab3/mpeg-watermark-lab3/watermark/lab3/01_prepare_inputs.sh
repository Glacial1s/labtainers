#!/bin/bash
set -euo pipefail
BASE="/home/student/watermark"
LAB2="$BASE/lab2"
mkdir -p "$LAB2/results"
echo "[1/5] Preparing Lab 3 input artifacts from sample.mp4..."
ffmpeg -i "$BASE/media/sample.mp4" -vf "select=eq(pict_type\,I)" -vsync vfr -vframes 1 \
       "$LAB2/results/iframe_orig.png" -y -loglevel quiet
cd "$LAB2"
python3 batch_embed.py
echo "[+] Created: $LAB2/results/iframe_orig.png"
echo "[+] Created: $LAB2/results/watermarked.mp4"
