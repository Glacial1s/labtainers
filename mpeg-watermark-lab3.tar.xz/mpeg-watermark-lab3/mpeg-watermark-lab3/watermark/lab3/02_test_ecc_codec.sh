#!/bin/bash
set -euo pipefail
LAB3="/home/student/watermark/lab3"
cd "$LAB3"
echo "[2/5] Testing the ECC/repetition-code recovery logic..."
python3 ecc.py
