#!/bin/bash
set -euo pipefail
LAB3="/home/student/watermark/lab3"
cd "$LAB3"
echo "[3/5] Running MPEG/H.264 re-encoding robustness test..."
bash robustness_test.sh
