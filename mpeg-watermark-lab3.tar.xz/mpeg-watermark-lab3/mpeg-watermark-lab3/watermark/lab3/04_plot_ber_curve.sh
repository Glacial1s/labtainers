#!/bin/bash
set -euo pipefail
LAB3="/home/student/watermark/lab3"
cd "$LAB3"
echo "[4/5] Plotting BER versus re-encoding bitrate..."
python3 plot_ber.py
