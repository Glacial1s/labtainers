#!/bin/bash
set -euo pipefail
LAB3="/home/student/watermark/lab3"
echo "[5/5] Finalizing Lab 3 evidence marker..."
echo "lab3_done=1" > "$LAB3/results/lab3_done.txt"
cat "$LAB3/results/ber_results.txt"
echo "[+] Lab 3 sequential workflow complete."
