#!/usr/bin/env python3
"""Lab 3: Error-correction demo. Uses bchlib when available; falls back to repetition code."""
from typing import List, Optional

def bits_to_bytes(bits):
    result = bytearray()
    bits = list(bits)
    for i in range(0, len(bits), 8):
        chunk = bits[i:i+8]
        while len(chunk) < 8:
            chunk.append(0)
        result.append(int(''.join(map(str, chunk)), 2))
    return result

def bytes_to_bits(data):
    return [(b >> (7 - i)) & 1 for b in data for i in range(8)]

def encode_bch(data_bits: List[int], t=4) -> List[int]:
    try:
        import bchlib
        bch = bchlib.BCH(t=t, m=8)
        db = bits_to_bytes(data_bits)
        ecc = bch.encode(db)
        return bytes_to_bits(db + ecc)
    except Exception:
        return [bit for b in data_bits for bit in (b, b, b)]

def decode_bch(encoded_bits: List[int], num_data_bits: int, t=4) -> Optional[List[int]]:
    try:
        import bchlib
        bch = bchlib.BCH(t=t, m=8)
        data_bytes_len = (num_data_bits + 7) // 8
        all_bytes = bits_to_bytes(encoded_bits)
        db = bytearray(all_bytes[:data_bytes_len])
        ecc = bytearray(all_bytes[data_bytes_len:])
        bitflips = bch.decode(db, ecc)
        if bitflips < 0:
            return None
        bch.correct(db, ecc)
        return bytes_to_bits(db)[:num_data_bits]
    except Exception:
        decoded = []
        for i in range(0, min(len(encoded_bits), num_data_bits * 3), 3):
            tri = encoded_bits[i:i+3]
            decoded.append(1 if sum(tri) >= 2 else 0)
        return decoded[:num_data_bits]

if __name__ == "__main__":
    data = [1,0,1,1,0,0,1,1]
    enc = encode_bch(data)
    print(f"Original : {data}")
    print(f"Encoded  : {enc[:32]}... length={len(enc)}")
    if len(enc) >= 4:
        enc[0] ^= 1; enc[3] ^= 1
    dec = decode_bch(enc, len(data))
    print(f"Recovered: {dec}")
    print(f"OK       : {dec == data}")
