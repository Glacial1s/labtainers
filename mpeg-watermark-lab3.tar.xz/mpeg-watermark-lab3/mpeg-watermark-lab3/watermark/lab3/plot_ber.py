#!/usr/bin/env python3
"""Lab 3: Plot BER vs re-encoding bitrate."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv

def plot_ber(csv_path, out_png):
    bitrates, bers = [], []
    with open(csv_path, encoding='utf-8') as f:
        next(f)
        for row in csv.reader(f):
            if not row:
                continue
            bitrates.append(row[0])
            bers.append(float(row[1]))
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(bitrates, bers, 'o-', linewidth=2, markersize=7)
    ax.axhline(10, ls='--', label='Acceptable BER threshold = 10%')
    ax.set_xlabel('Re-encoding bitrate')
    ax.set_ylabel('Bit error rate BER (%)')
    ax.set_title('Watermark robustness against MPEG/H.264 re-encoding')
    ax.grid(True, alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    print(f'[+] Plot saved to: {out_png}')

if __name__ == '__main__':
    plot_ber('/home/student/watermark/lab3/results/ber_results.txt',
             '/home/student/watermark/lab3/results/ber_vs_bitrate.png')
