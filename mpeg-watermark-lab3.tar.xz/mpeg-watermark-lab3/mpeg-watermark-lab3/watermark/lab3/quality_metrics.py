#!/usr/bin/env python3
import numpy as np
from skimage.metrics import structural_similarity as ssim

def psnr(a, b):
    mse = np.mean((a.astype(float) - b.astype(float)) ** 2)
    return float('inf') if mse == 0 else 10 * np.log10(255 ** 2 / mse)

def ssim_gray(a, b):
    return ssim(a, b, data_range=255)
