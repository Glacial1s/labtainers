#!/bin/bash
set -euo pipefail
BASE="/home/student/watermark"
LAB2="$BASE/lab2"
LAB3="$BASE/lab3"
RESULTS="$LAB3/results"
mkdir -p "$RESULTS"
cd "$LAB3"

if [ ! -f "$LAB2/results/watermarked.mp4" ] || [ ! -f "$LAB2/results/iframe_orig.png" ]; then
    echo "[!] Missing Lab 3 input artifacts."
    echo "    Run: bash /home/student/watermark/lab3/01_prepare_inputs.sh"
    exit 1
fi

WM_VIDEO="$LAB2/results/watermarked.mp4"
ORIG_FRAME="$LAB2/results/iframe_orig.png"
KEY="secret2024"
BITS="10110011"

echo "Bitrate,BER_percent" > "$RESULTS/ber_results.txt"

for BITRATE in 4000k 1000k 500k; do
    echo -n "  Re-encoding at bitrate $BITRATE... "
    ffmpeg -i "$WM_VIDEO" -t 2 -c:v libx264 -preset ultrafast -b:v "$BITRATE" -an \
           "$RESULTS/reencoded_${BITRATE}.mp4" -y -loglevel quiet
    ffmpeg -i "$RESULTS/reencoded_${BITRATE}.mp4" -vframes 1 \
           "$RESULTS/frame_${BITRATE}.png" -y -loglevel quiet 2>/dev/null
    BER=$(python3 - <<PY
import sys, cv2
sys.path.insert(0, '/home/student/watermark/lab2')
from extract_ss import extract_ss
orig = cv2.imread('$ORIG_FRAME', cv2.IMREAD_GRAYSCALE)
wm = cv2.imread('$RESULTS/frame_${BITRATE}.png', cv2.IMREAD_GRAYSCALE)
key = b'$KEY'
expected = [int(b) for b in '$BITS']
errors = 0
for i, bit in enumerate(expected):
    ext = extract_ss(orig, wm, key, i)
    errors += int(ext != bit)
print(f'{errors / len(expected) * 100:.1f}')
PY
)
    echo "BER=$BER%"
    echo "$BITRATE,$BER" >> "$RESULTS/ber_results.txt"
done

echo ""
cat "$RESULTS/ber_results.txt"
