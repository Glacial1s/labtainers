#!/bin/bash
set -euo pipefail
LAB3="/home/student/watermark/lab3"
bash "$LAB3/01_prepare_inputs.sh"
bash "$LAB3/02_test_ecc_codec.sh"
bash "$LAB3/03_run_reencoding_robustness.sh"
bash "$LAB3/04_plot_ber_curve.sh"
bash "$LAB3/05_finalize_lab3.sh"
