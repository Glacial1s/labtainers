#!/bin/bash
set -e

CUSTOMER=${1:-bob}

pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
rm -rf stolen leaked public out
mkdir -p stolen leaked public out

echo "[Attacker] Steal ${CUSTOMER}.mpg from distributor"

wget -q -O "stolen/${CUSTOMER}.mpg" "http://distributor:8000/${CUSTOMER}.mpg" || \
wget -q -O "stolen/${CUSTOMER}.mpg" "http://10.5.0.20:8000/${CUSTOMER}.mpg"

echo "[Attacker] Apply laundering attack"

ffmpeg -y -i "stolen/${CUSTOMER}.mpg" \
  -vf "scale=264:216,scale=352:288,noise=alls=6:allf=t" \
  -c:v mpeg2video \
  -b:v 750k \
  -g 12 \
  -bf 2 \
  -pix_fmt yuv420p \
  "leaked/suspect.mpg" >/dev/null 2>&1

sha256sum "leaked/suspect.mpg" > "leaked/suspect.sha256"

cp leaked/suspect.mpg public/suspect.mpg
cp leaked/suspect.sha256 public/suspect.sha256

cat > public/attack_note.txt <<NOTE
ATTACKER_SELECTED=${CUSTOMER}
ATTACK=scale_down_up+noise_light+reencode_750k
NOTE

# Serve public artifacts for the next lab container.
pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
(cd public && nohup python3 -m http.server 8000 --bind 0.0.0.0 > ../out/http_attacker.log 2>&1 &)
sleep 1

echo "ATTACK_OK=1"
