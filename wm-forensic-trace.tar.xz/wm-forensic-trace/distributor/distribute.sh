#!/bin/bash
set -e

pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
rm -rf incoming distributed configs schedules out public
mkdir -p incoming distributed configs schedules out public

echo "[Distributor] Fetch owner package"

wget -q -O incoming/owner_marked.mpg http://owner:8000/owner_marked.mpg || \
wget -q -O incoming/owner_marked.mpg http://10.5.0.10:8000/owner_marked.mpg

wget -q -O incoming/owner_schedule.json http://owner:8000/owner_schedule.json || \
wget -q -O incoming/owner_schedule.json http://10.5.0.10:8000/owner_schedule.json

wget -q -O incoming/owner_config.json http://owner:8000/owner_config.json || \
wget -q -O incoming/owner_config.json http://10.5.0.10:8000/owner_config.json

wget -q -O incoming/asset_metadata.json http://owner:8000/asset_metadata.json || \
wget -q -O incoming/asset_metadata.json http://10.5.0.10:8000/asset_metadata.json

echo "[Distributor] Create customer watermarked copies"

tail -n +2 customer_map.csv | while IFS=, read -r customer payload seed || [ -n "$customer" ]; do
  # Be tolerant of blank lines and CRLF-formatted CSV files.
  customer="${customer//$'\r'/}"
  payload="${payload//$'\r'/}"
  seed="${seed//$'\r'/}"
  [ -z "$customer" ] && continue

  cfg="configs/${customer}_config.json"
  schedule="schedules/${customer}_schedule.json"
  outvideo="distributed/${customer}.mpg"

  CFG="$cfg" PAYLOAD="$payload" SEED="$seed" python3 - <<'PY'
import json
import os
cfg = json.load(open("distributor_config_template.json"))
cfg["payload"] = os.environ["PAYLOAD"]
cfg["seed"] = int(os.environ["SEED"])
json.dump(cfg, open(os.environ["CFG"], "w"), indent=2)
PY

  python3 wm_tool.py embed \
    --config "$cfg" \
    --input incoming/owner_marked.mpg \
    --output "$outvideo" \
    --schedule "$schedule" \
    --workdir "out/embed_${customer}"

  sha256sum "$outvideo" > "distributed/${customer}.sha256"
done

echo "[Distributor] Export public verification package"

cp customer_map.csv public/customer_map.csv
cp incoming/owner_config.json public/owner_config.json
cp incoming/owner_schedule.json public/owner_schedule.json
cp incoming/asset_metadata.json public/asset_metadata.json
cp -r configs public/configs
cp -r schedules public/schedules
cp distributed/*.mpg public/

# Serve public artifacts for the next lab container.
pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
(cd public && nohup python3 -m http.server 8000 --bind 0.0.0.0 > ../out/http_distributor.log 2>&1 &)
sleep 1

echo "DISTRIBUTION_OK=1"
