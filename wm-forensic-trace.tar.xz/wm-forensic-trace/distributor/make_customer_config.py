#!/usr/bin/env python3
"""Tao file cau hinh watermark cho tung khach hang tu template."""
import argparse
import json
from pathlib import Path

ap = argparse.ArgumentParser(description="Tao config watermark cho tung customer")
ap.add_argument("--template", default="distributor_config_template.json")
ap.add_argument("--customer", required=True)
ap.add_argument("--payload", required=True)
ap.add_argument("--seed", required=True, type=int)
ap.add_argument("--out", required=True)
args = ap.parse_args()

cfg = json.loads(Path(args.template).read_text())
cfg["customer_id"] = args.customer
cfg["payload"] = args.payload
cfg["seed"] = int(args.seed)
Path(args.out).parent.mkdir(parents=True, exist_ok=True)
Path(args.out).write_text(json.dumps(cfg, indent=2))
print(f"CUSTOMER_CONFIG_CREATED={args.customer}")
print(f"CONFIG={args.out}")
