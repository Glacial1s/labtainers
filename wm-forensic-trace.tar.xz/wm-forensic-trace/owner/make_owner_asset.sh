#!/bin/bash
set -e

pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
rm -rf videos out public
mkdir -p videos out public

echo "[Owner] Create source video"
python3 wm_tool.py make-source \
  --out videos/source.mpg \
  --duration 4 \
  --width 352 \
  --height 288 \
  --rate 25 \
  --gop 12 \
  --q 4

echo "[Owner] Embed owner watermark"
python3 wm_tool.py embed \
  --config owner_config.json \
  --input videos/source.mpg \
  --output videos/owner_marked.mpg \
  --schedule out/owner_schedule.json \
  --workdir out/owner_embed

echo "[Owner] Export package"
cp videos/owner_marked.mpg public/owner_marked.mpg
cp out/owner_schedule.json public/owner_schedule.json
cp owner_config.json public/owner_config.json

sha256sum videos/source.mpg > public/source_hash.txt
sha256sum videos/owner_marked.mpg > public/owner_marked_hash.txt

cat > public/asset_metadata.json <<META
{
  "asset_id": "ASSET-2026-001",
  "owner": "STUDIO-ALPHA",
  "codec": "MPEG-2",
  "watermark_scheme": "DCT-mid-frequency-adaptive-ECC"
}
META

# Serve public artifacts for the next lab container.
pkill -f "python3 -m http.server 8000" >/dev/null 2>&1 || true
(cd public && nohup python3 -m http.server 8000 --bind 0.0.0.0 > ../out/http_owner.log 2>&1 &)
sleep 1

echo "OWNER_ASSET_OK=1"
