#!/usr/bin/env python3
import pathlib
import re

report = pathlib.Path("verification_report.txt")
txt = report.read_text(errors="ignore") if report.exists() else ""

def has_flag(name: str) -> bool:
    return re.search(rf"^{re.escape(name)}=1$", txt, re.MULTILINE) is not None

def get_float(name: str, default: float) -> float:
    m = re.search(rf"^{re.escape(name)}=([0-9.]+)$", txt, re.MULTILINE)
    return float(m.group(1)) if m else default

owner = has_flag("OWNER_MATCH")
dist = has_flag("DISTRIBUTOR_MATCH")

m = re.search(r"^SUSPECT_CUSTOMER=([A-Za-z0-9_.-]+)$", txt, re.MULTILINE)
customer_ok = m is not None and m.group(1) != "UNKNOWN"

confidence = get_float("CONFIDENCE", 0.0)
ber_owner = get_float("BER_OWNER", 1.0)
ber_customer = get_float("BER_CUSTOMER", 1.0)


print(f"REPORT_OK={int(report.exists())}")
print(f"OWNER_MATCH={int(owner)}")
print(f"DISTRIBUTOR_MATCH={int(dist)}")
print(f"CUSTOMER_IDENTIFIED={int(customer_ok)}")
print(f"CONFIDENCE={confidence:.4f}")
print(f"CONFIDENCE_OK={int(confidence >= 0.60)}")
print(f"BER_OWNER={ber_owner:.4f}")
print(f"BER_OWNER_OK={int(ber_owner <= 0.35)}")
print(f"BER_CUSTOMER={ber_customer:.4f}")
print(f"BER_CUSTOMER_OK={int(ber_customer <= 0.35)}")
