#!/usr/bin/env python3
import argparse
import csv
import pathlib
import re
import subprocess

def run(cmd):
    return subprocess.run(cmd, shell=True, text=True, capture_output=True)

def parse_extract(txt):
    out = {
        "final_ber": 1.0,
        "raw_ber": 1.0,
        "confidence": 0.0,
        "detected": 0
    }

    m = re.search(r"FINAL_BER=([0-9.]+)", txt)
    if m:
        out["final_ber"] = float(m.group(1))

    m = re.search(r"RAW_BER=([0-9.]+)", txt)
    if m:
        out["raw_ber"] = float(m.group(1))

    m = re.search(r"CONFIDENCE=([0-9.]+)", txt)
    if m:
        out["confidence"] = float(m.group(1))

    m = re.search(r"DETECTED=([01])", txt)
    if m:
        out["detected"] = int(m.group(1))

    return out

def fetch_inputs():
    pathlib.Path("incoming").mkdir(exist_ok=True)
    pathlib.Path("incoming/configs").mkdir(parents=True, exist_ok=True)
    pathlib.Path("incoming/schedules").mkdir(parents=True, exist_ok=True)
    pathlib.Path("evidence").mkdir(exist_ok=True)

    commands = [
        "wget -q -O incoming/suspect.mpg http://attacker:8000/suspect.mpg || wget -q -O incoming/suspect.mpg http://10.5.0.30:8000/suspect.mpg",
        "wget -q -O incoming/customer_map.csv http://distributor:8000/customer_map.csv || wget -q -O incoming/customer_map.csv http://10.5.0.20:8000/customer_map.csv",
        "wget -q -O incoming/owner_config.json http://distributor:8000/owner_config.json || wget -q -O incoming/owner_config.json http://10.5.0.20:8000/owner_config.json",
        "wget -q -O incoming/owner_schedule.json http://distributor:8000/owner_schedule.json || wget -q -O incoming/owner_schedule.json http://10.5.0.20:8000/owner_schedule.json",
        "wget -q -O incoming/asset_metadata.json http://distributor:8000/asset_metadata.json || wget -q -O incoming/asset_metadata.json http://10.5.0.20:8000/asset_metadata.json"
    ]

    for cmd in commands:
        p = run(cmd)
        if p.returncode != 0:
            raise SystemExit("Fetch failed: " + cmd + "\n" + p.stderr)

    with open("incoming/customer_map.csv") as f:
        rows = list(csv.DictReader(f))

    for r in rows:
        c = r["customer_id"]

        cmd1 = f"wget -q -O incoming/configs/{c}_config.json http://distributor:8000/configs/{c}_config.json || wget -q -O incoming/configs/{c}_config.json http://10.5.0.20:8000/configs/{c}_config.json"
        cmd2 = f"wget -q -O incoming/schedules/{c}_schedule.json http://distributor:8000/schedules/{c}_schedule.json || wget -q -O incoming/schedules/{c}_schedule.json http://10.5.0.20:8000/schedules/{c}_schedule.json"

        if run(cmd1).returncode != 0:
            raise SystemExit("Could not fetch customer config for " + c)

        if run(cmd2).returncode != 0:
            raise SystemExit("Could not fetch customer schedule for " + c)

    return rows

def load_rows_from_incoming():
    path = pathlib.Path("incoming/customer_map.csv")
    if not path.exists():
        raise SystemExit("Missing incoming/customer_map.csv. Hay tai customer_map.csv tu distributor truoc.")
    with open(path) as f:
        return list(csv.DictReader(f))

def main():
    ap = argparse.ArgumentParser(description="Xac minh nghi pham ro ri video")
    ap.add_argument("--skip-fetch", action="store_true",
                    help="Khong tu dong wget. Dung cac file sinh vien da tai san trong incoming/.")
    args = ap.parse_args()
    if args.skip_fetch:
        pathlib.Path("evidence").mkdir(exist_ok=True)
        rows = load_rows_from_incoming()
    else:
        rows = fetch_inputs()

    owner_proc = run(
        "python3 wm_tool.py extract "
        "--config incoming/owner_config.json "
        "--input incoming/suspect.mpg "
        "--schedule incoming/owner_schedule.json "
        "--workdir evidence/extract_owner"
    )

    if owner_proc.returncode != 0:
        raise SystemExit("Owner extraction failed:\n" + owner_proc.stdout + owner_proc.stderr)
    owner = parse_extract(owner_proc.stdout + owner_proc.stderr)

    candidates = []

    for r in rows:
        customer = r["customer_id"]

        p = run(
            "python3 wm_tool.py extract "
            f"--config incoming/configs/{customer}_config.json "
            "--input incoming/suspect.mpg "
            f"--schedule incoming/schedules/{customer}_schedule.json "
            f"--workdir evidence/extract_{customer}"
        )

        if p.returncode != 0:
            raise SystemExit(f"Customer extraction failed for {customer}:\n" + p.stdout + p.stderr)
        res = parse_extract(p.stdout + p.stderr)
        res["customer"] = customer
        candidates.append(res)

    if not candidates:
        raise SystemExit("No customer candidates were loaded from incoming/customer_map.csv")

    candidates.sort(key=lambda x: (x["final_ber"], -x["confidence"]))
    best = candidates[0]
    second = candidates[1] if len(candidates) > 1 else None

    if second:
        margin = second["final_ber"] - best["final_ber"]
    else:
        margin = 1.0 - best["final_ber"]

    confidence = max(0.0, min(1.0, 1.0 - best["final_ber"] + margin))

    owner_match = int(owner["detected"] == 1)
    distributor_match = int(best["detected"] == 1 and best["final_ber"] <= 0.30)
    suspect_customer = best["customer"] if distributor_match else "UNKNOWN"

    with open("verification_report.txt", "w") as f:
        f.write("=== VERIFICATION REPORT ===\n")
        f.write(f"OWNER_MATCH={owner_match}\n")
        f.write(f"BER_OWNER={owner['final_ber']:.4f}\n")
        f.write(f"OWNER_CONFIDENCE={owner['confidence']:.4f}\n")
        f.write(f"DISTRIBUTOR_MATCH={distributor_match}\n")
        f.write(f"SUSPECT_CUSTOMER={suspect_customer}\n")
        f.write(f"BER_CUSTOMER={best['final_ber']:.4f}\n")
        f.write(f"CUSTOMER_CONFIDENCE={best['confidence']:.4f}\n")
        f.write(f"CONFIDENCE={confidence:.4f}\n")
        f.write("\n--- All customer candidates ---\n")

        for c in candidates:
            f.write(
                f"{c['customer']},BER={c['final_ber']:.4f},"
                f"RAW_BER={c['raw_ber']:.4f},"
                f"CONF={c['confidence']:.4f},"
                f"DETECTED={c['detected']}\n"
            )

    print(pathlib.Path("verification_report.txt").read_text())

if __name__ == "__main__":
    main()

